var searchData=
[
  ['sentinel',['sentinel',['../classcpp__redis_1_1sentinel.html',1,'cpp_redis']]],
  ['sentinel_5fdef',['sentinel_def',['../classcpp__redis_1_1sentinel_1_1sentinel__def.html',1,'cpp_redis::sentinel']]],
  ['simple_5fstring_5fbuilder',['simple_string_builder',['../classcpp__redis_1_1builders_1_1simple__string__builder.html',1,'cpp_redis::builders']]],
  ['subscriber',['subscriber',['../classcpp__redis_1_1subscriber.html',1,'cpp_redis']]]
];
