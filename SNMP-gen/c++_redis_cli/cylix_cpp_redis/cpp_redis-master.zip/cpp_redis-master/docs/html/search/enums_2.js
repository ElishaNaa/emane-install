var searchData=
[
  ['client_5ftype',['client_type',['../classcpp__redis_1_1client.html#a388877b01b4e045cddb138e70a68e000',1,'cpp_redis::client']]],
  ['connect_5fstate',['connect_state',['../classcpp__redis_1_1client.html#a2512bd48dd45391249a69bd720c1e4da',1,'cpp_redis::client::connect_state()'],['../classcpp__redis_1_1subscriber.html#afc976757efd9d0ac4def6935546a2338',1,'cpp_redis::subscriber::connect_state()']]]
];
