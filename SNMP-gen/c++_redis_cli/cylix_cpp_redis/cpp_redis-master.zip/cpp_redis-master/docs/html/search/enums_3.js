var searchData=
[
  ['geo_5funit',['geo_unit',['../classcpp__redis_1_1client.html#aa5998536fd32ff4387c89be514997620',1,'cpp_redis::client']]]
];
