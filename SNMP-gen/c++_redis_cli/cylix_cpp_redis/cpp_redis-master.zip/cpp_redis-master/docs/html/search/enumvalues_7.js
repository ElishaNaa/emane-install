var searchData=
[
  ['master',['master',['../classcpp__redis_1_1client.html#a388877b01b4e045cddb138e70a68e000aeb0a191797624dd3a48fa681d3061212',1,'cpp_redis::client']]]
];
