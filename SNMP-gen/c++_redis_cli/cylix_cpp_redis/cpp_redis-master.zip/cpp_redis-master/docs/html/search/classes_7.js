var searchData=
[
  ['read_5frequest',['read_request',['../structcpp__redis_1_1network_1_1tcp__client__iface_1_1read__request.html',1,'cpp_redis::network::tcp_client_iface']]],
  ['read_5fresult',['read_result',['../structcpp__redis_1_1network_1_1tcp__client__iface_1_1read__result.html',1,'cpp_redis::network::tcp_client_iface']]],
  ['redis_5fconnection',['redis_connection',['../classcpp__redis_1_1network_1_1redis__connection.html',1,'cpp_redis::network']]],
  ['redis_5ferror',['redis_error',['../classcpp__redis_1_1redis__error.html',1,'cpp_redis']]],
  ['reply',['reply',['../classcpp__redis_1_1reply.html',1,'cpp_redis']]],
  ['reply_5fbuilder',['reply_builder',['../classcpp__redis_1_1builders_1_1reply__builder.html',1,'cpp_redis::builders']]]
];
