var searchData=
[
  ['connect_5fcallback_5ft',['connect_callback_t',['../classcpp__redis_1_1client.html#a4bb592b64ededde5a6fcf8111ca2548f',1,'cpp_redis::client::connect_callback_t()'],['../classcpp__redis_1_1subscriber.html#a90f2f7d4c748c3c2e89d1e977fa6dce1',1,'cpp_redis::subscriber::connect_callback_t()']]]
];
