var searchData=
[
  ['error_5fbuilder',['error_builder',['../classcpp__redis_1_1builders_1_1error__builder.html',1,'cpp_redis::builders']]]
];
