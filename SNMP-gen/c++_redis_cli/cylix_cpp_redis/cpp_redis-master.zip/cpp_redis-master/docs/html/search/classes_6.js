var searchData=
[
  ['logger',['logger',['../classcpp__redis_1_1logger.html',1,'cpp_redis']]],
  ['logger_5fiface',['logger_iface',['../classcpp__redis_1_1logger__iface.html',1,'cpp_redis']]]
];
